import pygame
from Object import Object

class Player(Object):
    def __init__(self, x, y, ancho, alto, image=None, color = (255,0,0)):
        super().__init__(x, y, ancho, alto, image, color)

    def mover(self, dx, dy):
        self.__x = dx + self.get_pos()[0]
        self.__y = dy + self.get_pos()[1]

        self.set_pos(self.__x, self.__y)

    def control_manual(self, event, VELOCIDAD, dx, dy):     
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                dx, dy = -VELOCIDAD, 0
            if event.key == pygame.K_RIGHT:
                dx, dy = VELOCIDAD, 0
            if event.key == pygame.K_UP:
                dx, dy = 0, -VELOCIDAD
            if event.key == pygame.K_DOWN:
                dx, dy = 0, VELOCIDAD

        return dx, dy

    