import pygame

class Object:
    def __init__(self, X, Y, ancho, alto, image=None, color=(0,255,0)):
        self.__x = X
        self.__y = Y
        self.__ancho = ancho
        self.__alto = alto
        self.__color = color
        self.rect = pygame.Rect(self.__x, self.__y, self.__ancho, self.__alto)

        if image:
            self.__image = pygame.image.load(image)
            self.__image = pygame.transform.scale(self.__image, (self.__ancho, self.__alto))
        else:
            self.__image = None

    def get_pos(self):
        return self.__x, self.__y
    
    def get_size(self):
        return self.__ancho, self.__alto
    
    def set_pos(self, x, y):
        self.__x = x
        self.__y = y

    def set_size(self, ancho, alto):
        self.__ancho = ancho
        self.__alto = alto

    def dibujar(self, juego):
        self.rect.center = juego.pos_grid(self.__x, self.__y)  

        if self.__image: 
            juego.get_pantalla.blit(self.__image, self.rect.topleft)
        else:  
            pygame.draw.rect(juego.get_pantalla, self.__color, self.rect)

    def cambiar_color(self, color):
        self.__color = color