import pygame
import sys
import random
from Player import Player
from Display import Display
from Object import Object

ANCHO = 630
ALTO = 630
TAM_CELDA = 30
FPS = 15

COLORES = {'BLANCO': (255, 255, 255),
           'NEGRO': (0, 0, 0),
           'ROJO': (255, 0, 0),
           'VERDE': (0, 255, 0),
           'AZUL': (0, 0, 255)}

# VERDE PASTEL OSCURO (119, 221, 119)
# VERDE PASTEL CLARO (152, 251, 152)
# ROJO PASTEL (255, 105, 97)

def main():

    juego = Display(ANCHO, ALTO, 'HungryRacoon', FPS, TAM_CELDA)
    juego.set_display()
    icono = pygame.image.load("racoon.png")  
    pygame.display.set_icon(icono)
    
    racoon = Player(random.randint(0, ANCHO//TAM_CELDA-1),random.randint(2, ALTO//TAM_CELDA-1), TAM_CELDA, TAM_CELDA, 'racoon.png')
    apple = Object(random.randint(0, ANCHO//TAM_CELDA-1),random.randint(2, ALTO//TAM_CELDA-1),TAM_CELDA, TAM_CELDA, 'apple.png')

    VELOCIDAD = 1
    dx, dy = 0,0
    PUNTAJE = 0
    POSTEXT = (15, TAM_CELDA // 2 - 6)

    fondo = pygame.image.load("grass.png").convert()
    fondo = pygame.transform.scale(fondo, (ANCHO, ALTO - 2 * TAM_CELDA))
    fondoWin = pygame.image.load("win.png").convert()
    fondoWin = pygame.transform.scale(fondoWin, (ANCHO, ALTO))
    fuente = pygame.font.SysFont("Comic Sans MS", 25)  
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        
            dx, dy = racoon.control_manual(event, VELOCIDAD, dx, dy)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    pygame.quit()
                    sys.exit()
        
        X, Y = racoon.get_pos()

        if X + dx >= 0 and X + dx <= juego.get_ancho() // juego.get_tam_celda() -1: 
            racoon.mover(dx, 0)
        if Y + dy > 1 and Y + dy <= juego.get_alto() // juego.get_tam_celda() -1:
            racoon.mover(0, dy)

        if racoon.get_pos() == apple.get_pos():
        #if racoon.rect.colliderect(apple.rect):
            PUNTAJE += 1
            apple.set_pos(random.randint(0, ANCHO//TAM_CELDA-1),random.randint(2, ALTO//TAM_CELDA-1))

        if PUNTAJE == 10: 
            juego.get_pantalla.blit(fondoWin, (0, 0))
            pygame.display.flip()
            pygame.time.delay(3000)  
            pygame.quit()
            sys.exit()

        juego.get_pantalla.fill((173, 216, 240))
        juego.get_pantalla.blit(fondo, (0, 2 * TAM_CELDA))
        #juego.dibujar_grid((119, 221, 119))    

        racoon.dibujar(juego)
        apple.dibujar(juego)

        texto = fuente.render(f"PUNTAJE: {PUNTAJE}", True, COLORES['NEGRO'])  
        juego.get_pantalla.blit(texto, POSTEXT)

        pygame.display.flip()
        juego.reloj.tick(juego.get_fps())


if __name__ == "__main__":
    main()
